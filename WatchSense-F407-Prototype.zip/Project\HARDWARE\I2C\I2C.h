#ifndef __I2C_H
#define __I2C_H

#include "sys.h"

// PB8: SCL, PB9: SDA
#define I2C_SCL_PIN        GPIO_Pin_8
#define I2C_SDA_PIN        GPIO_Pin_9
#define I2C_PORT           GPIOB
#define I2C_PORT_CLK       RCC_AHB1Periph_GPIOB

#define SCL                PBout(8)
#define SDA                PBout(9)
#define READ_SDA           PBin(9)

#define SDA_IN()           do { GPIOB->MODER &= ~(3 << (9 * 2)); } while (0)
#define SDA_OUT()          do { GPIOB->MODER &= ~(3 << (9 * 2)); GPIOB->MODER |= 1 << (9 * 2); } while (0)

void myI2C_init(void);
void I2C_BusRecover(void);
void Start(void);
void Stop(void);
void Ack(void);
u8 Wait_Ack(void);
void Nack(void);
void Send_Byte(u8 txd);
u8 Read_Byte(unsigned char ack);

u8 i2c_write(u8 addr_7bit, const u8 *buf, u16 len);
u8 i2c_read(u8 addr_7bit, u8 *buf, u16 len);
u8 I2C_WriteReg(u8 addr_7bit, u8 reg, u8 data);
u8 I2C_WriteMulti(u8 addr_7bit, u8 reg, const u8 *buf, u16 len);
u8 I2C_ReadReg(u8 addr_7bit, u8 reg, u8 *data);
u8 I2C_ReadMulti(u8 addr_7bit, u8 reg, u8 *buf, u16 len);

#endif
