#include "sys.h"
#include "delay.h"
#include "led.h"
#include "beep.h"
#include "key.h"
#include "usart.h"
#include "I2C.h"
#include "VL53L0X.h"
#include "bme280_port.h"
#include "oled.h"
#include "max30102.h"
#include <stdio.h>

#define KEY_NONE        0
#define KEY0_PRESS      1
#define KEY1_PRESS      2
#define KEY2_PRESS      3
#define WKUP_PRESS      4

#define CAL_TARGET_MM   100

typedef enum
{
    PAGE_DASHBOARD = 0,
    PAGE_ENVIRONMENT,
    PAGE_DISTANCE,
    PAGE_HEALTH,
    PAGE_MOTION_TODO,
    PAGE_COUNT
} StationPage;

static const u16 alarm_thresholds[] = {80, 150, 300, 600};
static const enum VL53L0X_Profile vl_profiles[] =
{
    VL53L0X_PROFILE_DEFAULT,
    VL53L0X_PROFILE_HIGH_SPEED,
    VL53L0X_PROFILE_HIGH_ACCURACY,
    VL53L0X_PROFILE_LONG_RANGE
};
static const char *vl_profile_names[] =
{
    "default",
    "speed",
    "accuracy",
    "long"
};
static const char *page_names[] =
{
    "dashboard",
    "environment",
    "distance",
    "health",
    "motion-todo"
};

static struct bme280_dev bme_dev;
static struct bme280_settings bme_settings;
static struct bme280_data bme_data;
static uint32_t bme_meas_delay_us;
static u8 bme_ready;
static u8 vl53_ready;
static u8 max30102_ready;
static u16 distance_mm = 65535;
static u8 alarm_enabled = 1;
static u8 threshold_index = 1;
static u8 profile_index = 0;
static StationPage current_page = PAGE_DASHBOARD;

static u8 KeyScan(void)
{
    u8 raw_key = KEY_NONE;
    static u8 last_raw_key = KEY_NONE;
    static u8 reported_key = KEY_NONE;
    static u8 stable_count = 0;

    if (KEY0 == 0)
    {
        raw_key = KEY0_PRESS;
    }
    else if (KEY1 == 0)
    {
        raw_key = KEY1_PRESS;
    }
    else if (KEY2 == 0)
    {
        raw_key = KEY2_PRESS;
    }
    else if (WK_UP == 1)
    {
        raw_key = WKUP_PRESS;
    }

    if (raw_key == last_raw_key)
    {
        if (stable_count < 3)
        {
            stable_count++;
        }
    }
    else
    {
        last_raw_key = raw_key;
        stable_count = 0;
    }

    if (stable_count < 2)
    {
        return KEY_NONE;
    }

    if (raw_key == KEY_NONE)
    {
        reported_key = KEY_NONE;
        return KEY_NONE;
    }

    if (reported_key != raw_key)
    {
        reported_key = raw_key;
        return raw_key;
    }

    return KEY_NONE;
}

static void PrintBmeResult(const char *api_name, int8_t rslt)
{
    if (rslt != BME280_OK)
    {
        printf("%s failed, code: %d\r\n", api_name, rslt);
    }
}

static void PrintBmeData(void)
{
    long temp_int;
    long temp_frac;
    unsigned long hum_int;
    unsigned long hum_frac;
    unsigned long press_int;
    unsigned long press_frac;

    if (!bme_ready)
    {
        printf("ENV: BME280 not ready\r\n");
        return;
    }

    temp_int = bme_data.temperature / 100;
    temp_frac = bme_data.temperature % 100;
    if (temp_frac < 0)
    {
        temp_frac = -temp_frac;
    }

    hum_int = bme_data.humidity / 1024;
    hum_frac = ((bme_data.humidity % 1024) * 100) / 1024;

    press_int = bme_data.pressure / 100;
    press_frac = bme_data.pressure % 100;

    printf("ENV: T=%ld.%02ld C, RH=%lu.%02lu %%, P=%lu.%02lu Pa\r\n",
           temp_int,
           temp_frac,
           hum_int,
           hum_frac,
           press_int,
           press_frac);
}

static void FormatBmeLine(char *line)
{
    long temp_int;
    long temp_frac;
    unsigned long hum_int;
    unsigned long hum_frac;

    if (!bme_ready)
    {
        sprintf(line, "ENV: --.-C --.-%%");
        return;
    }

    temp_int = bme_data.temperature / 100;
    temp_frac = bme_data.temperature % 100;
    if (temp_frac < 0)
    {
        temp_frac = -temp_frac;
    }

    hum_int = bme_data.humidity / 1024;
    hum_frac = ((bme_data.humidity % 1024) * 10) / 1024;

    sprintf(line, "ENV:%ld.%02ldC %lu.%lu%%",
            temp_int, temp_frac, hum_int, hum_frac);
}

static void FormatPressureLine(char *line)
{
    unsigned long press_hpa_int;
    unsigned long press_hpa_frac;

    if (!bme_ready)
    {
        sprintf(line, "AIR: ----.-hPa");
        return;
    }

    press_hpa_int = bme_data.pressure / 10000;
    press_hpa_frac = (bme_data.pressure % 10000) / 1000;

    sprintf(line, "AIR:%lu.%luhPa", press_hpa_int, press_hpa_frac);
}

static void FormatHealthLine(char *line)
{
    const MAX30102_Data *data;

    data = MAX30102_GetData();
    if (!max30102_ready || !data->ready)
    {
        sprintf(line, "HR:-- SPO2:--");
        return;
    }

    if (!data->finger)
    {
        sprintf(line, "HR:NO FINGER");
        return;
    }

    if (data->bpm > 0 && data->spo2_valid)
    {
        sprintf(line, "HR:%u SPO2:%u%%", data->bpm, data->spo2);
    }
    else if (data->bpm > 0)
    {
        sprintf(line, "HR:%u SPO2:..", data->bpm);
    }
    else
    {
        sprintf(line, "HR:... SPO2:..");
    }
}

static void PrintHealthData(void)
{
    const MAX30102_Data *data;

    data = MAX30102_GetData();
    if (!max30102_ready || !data->ready)
    {
        printf("HEALTH: MAX30102 not ready\r\n");
        return;
    }

    if (!data->finger)
    {
        printf("HEALTH: no finger, IR=%lu RED=%lu\r\n",
               (unsigned long)data->ir,
               (unsigned long)data->red);
        return;
    }

    if (data->spo2_valid)
    {
        printf("HEALTH: HR=%u bpm, SpO2=%u%%, IR=%lu, RED=%lu, beats=%u\r\n",
               data->bpm,
               data->spo2,
               (unsigned long)data->ir,
               (unsigned long)data->red,
               data->beat_count);
    }
    else
    {
        printf("HEALTH: HR=%u bpm, SpO2=pending, IR=%lu, RED=%lu, beats=%u\r\n",
               data->bpm,
               (unsigned long)data->ir,
               (unsigned long)data->red,
               data->beat_count);
    }
}

static u8 Bme280StationInit(void)
{
    int8_t rslt;

    BME280_SPI_Init();

    bme_dev.intf = BME280_SPI_INTF;
    bme_dev.read = user_spi_read;
    bme_dev.write = user_spi_write;
    bme_dev.delay_us = user_delay_us;
    bme_dev.intf_ptr = 0;
    bme_dev.intf_rslt = BME280_INTF_RET_SUCCESS;

    rslt = bme280_init(&bme_dev);
    PrintBmeResult("bme280_init", rslt);
    if (rslt != BME280_OK)
    {
        return 0;
    }

    rslt = bme280_get_sensor_settings(&bme_settings, &bme_dev);
    PrintBmeResult("bme280_get_sensor_settings", rslt);
    if (rslt != BME280_OK)
    {
        return 0;
    }

    bme_settings.osr_h = BME280_OVERSAMPLING_1X;
    bme_settings.osr_p = BME280_OVERSAMPLING_1X;
    bme_settings.osr_t = BME280_OVERSAMPLING_1X;
    bme_settings.filter = BME280_FILTER_COEFF_2;
    bme_settings.standby_time = BME280_STANDBY_TIME_1000_MS;

    rslt = bme280_set_sensor_settings(BME280_SEL_ALL_SETTINGS, &bme_settings, &bme_dev);
    PrintBmeResult("bme280_set_sensor_settings", rslt);
    if (rslt != BME280_OK)
    {
        return 0;
    }

    rslt = bme280_cal_meas_delay(&bme_meas_delay_us, &bme_settings);
    PrintBmeResult("bme280_cal_meas_delay", rslt);
    return (rslt == BME280_OK);
}

static void Bme280Sample(void)
{
    int8_t rslt;

    if (!bme_ready)
    {
        return;
    }

    rslt = bme280_set_sensor_mode(BME280_POWERMODE_FORCED, &bme_dev);
    PrintBmeResult("bme280_set_sensor_mode", rslt);
    if (rslt != BME280_OK)
    {
        bme_ready = 0;
        return;
    }

    bme_dev.delay_us(bme_meas_delay_us, bme_dev.intf_ptr);

    rslt = bme280_get_sensor_data(BME280_ALL, &bme_data, &bme_dev);
    PrintBmeResult("bme280_get_sensor_data", rslt);
    if (rslt != BME280_OK)
    {
        bme_ready = 0;
    }
}

static void Vl53StationInit(void)
{
    if (vl53_ready)
    {
        VL53L0X_StopContinuous();
    }

    vl53_ready = VL53L0X_Init();
    if (!vl53_ready)
    {
        printf("VL53L0X failed. I2C status=%u, model=0x%02X\r\n",
               VL53L0X_GetLastStatus(), VL53L0X_GetModelID());
        return;
    }

    VL53L0X_ApplyProfile(vl_profiles[profile_index]);
    VL53L0X_StartContinuous(0);
    printf("VL53L0X OK. profile=%s, timing=%lu us\r\n",
           vl_profile_names[profile_index], VL53L0X_GetMeasurementTimingBudget());
}

static void Max30102StationInit(void)
{
    max30102_ready = MAX30102_Init();
    if (!max30102_ready)
    {
        printf("MAX30102 failed. part_id=0x%02X, expected=0x%02X\r\n",
               MAX30102_GetPartID(), MAX30102_EXPECTED_ID);
        return;
    }

    printf("MAX30102 OK. addr=0x%02X, part_id=0x%02X\r\n",
           MAX30102_I2C_ADDR, MAX30102_GetData()->part_id);
}

static void RetryFailedSensors(void)
{
    if (!bme_ready)
    {
        printf("Retrying BME280...\r\n");
        bme_ready = Bme280StationInit();
        printf("BME280 %s\r\n", bme_ready ? "OK" : "FAIL");
    }

    if (!vl53_ready)
    {
        printf("Retrying VL53L0X...\r\n");
        Vl53StationInit();
    }

    if (!max30102_ready)
    {
        printf("Retrying MAX30102...\r\n");
        Max30102StationInit();
    }
}

static void Vl53Sample(void)
{
    if (!vl53_ready)
    {
        distance_mm = 65535;
        return;
    }

    distance_mm = VL53L0X_ReadFilteredMillimeters(2);
    if (VL53L0X_TimeoutOccurred())
    {
        printf("VL53L0X timeout\r\n");
        distance_mm = 65535;
    }
}

static void Max30102Sample(uint32_t now_ms)
{
    if (!max30102_ready)
    {
        return;
    }

    MAX30102_Task(now_ms, 0);
    if (!MAX30102_GetData()->ready)
    {
        max30102_ready = 0;
        printf("MAX30102 I2C lost\r\n");
    }
}

static void HandleKey(u8 key)
{
    if (key == KEY_NONE)
    {
        return;
    }

    if (key == KEY0_PRESS)
    {
        current_page = (StationPage)((current_page + 1) % PAGE_COUNT);
        printf("Page -> %s\r\n", page_names[current_page]);
    }
    else if (key == KEY1_PRESS)
    {
        if (!vl53_ready)
        {
            printf("VL53L0X profile skipped: sensor not ready\r\n");
            return;
        }

        profile_index++;
        if (profile_index >= (sizeof(vl_profiles) / sizeof(vl_profiles[0])))
        {
            profile_index = 0;
        }

        VL53L0X_StopContinuous();
        if (VL53L0X_ApplyProfile(vl_profiles[profile_index]))
        {
            printf("VL53L0X profile -> %s, timing=%lu us\r\n",
                   vl_profile_names[profile_index], VL53L0X_GetMeasurementTimingBudget());
        }
        else
        {
            printf("VL53L0X profile switch failed\r\n");
        }
        VL53L0X_StartContinuous(0);
    }
    else if (key == KEY2_PRESS)
    {
        if (!alarm_enabled)
        {
            alarm_enabled = 1;
            threshold_index = 0;
        }
        else
        {
            threshold_index++;
            if (threshold_index >= (sizeof(alarm_thresholds) / sizeof(alarm_thresholds[0])))
            {
                threshold_index = 0;
                alarm_enabled = 0;
            }
        }
        printf("Distance alarm -> %s, threshold=%u mm\r\n",
               alarm_enabled ? "on" : "off", alarm_thresholds[threshold_index]);
    }
    else if (key == WKUP_PRESS)
    {
        if (!vl53_ready)
        {
            alarm_enabled = !alarm_enabled;
            printf("Alarm -> %s\r\n", alarm_enabled ? "on" : "off");
            return;
        }

        printf("Calibrating VL53L0X offset at %u mm...\r\n", CAL_TARGET_MM);
        VL53L0X_StopContinuous();
        if (VL53L0X_CalibrateOffset(CAL_TARGET_MM, 20))
        {
            printf("Calibration OK, offset=%d mm\r\n", (int)VL53L0X_GetOffset());
        }
        else
        {
            printf("Calibration failed\r\n");
        }
        VL53L0X_StartContinuous(0);
    }
}

static void ApplyLinkage(void)
{
    u16 threshold = alarm_thresholds[threshold_index];

    if (vl53_ready && distance_mm != 65535 && alarm_enabled && distance_mm <= threshold)
    {
        LED1 = 0;
        BEEP = 1;
    }
    else
    {
        LED1 = 1;
        BEEP = 0;
    }
}

static void PrintStationFrame(void)
{
    printf("\r\n[%s] VL53L0X=%s BME280=%s MAX30102=%s GY-91=TODO alarm=%s threshold=%u mm\r\n",
           page_names[current_page],
           vl53_ready ? "OK" : "FAIL",
           bme_ready ? "OK" : "FAIL",
           max30102_ready ? "OK" : "FAIL",
           alarm_enabled ? "on" : "off",
           alarm_thresholds[threshold_index]);

    if (current_page == PAGE_DASHBOARD)
    {
        if (vl53_ready && distance_mm != 65535)
        {
            printf("DIST: %u mm, offset=%d mm, profile=%s\r\n",
                   distance_mm, (int)VL53L0X_GetOffset(), vl_profile_names[profile_index]);
        }
        else
        {
            printf("DIST: not ready\r\n");
        }
        PrintBmeData();
        PrintHealthData();
        printf("MOTION: waiting for GY-91 driver\r\n");
    }
    else if (current_page == PAGE_ENVIRONMENT)
    {
        PrintBmeData();
    }
    else if (current_page == PAGE_DISTANCE)
    {
        if (vl53_ready && distance_mm != 65535)
        {
            printf("DIST: %u mm, threshold=%u mm, offset=%d mm, profile=%s\r\n",
                   distance_mm,
                   alarm_thresholds[threshold_index],
                   (int)VL53L0X_GetOffset(),
                   vl_profile_names[profile_index]);
        }
        else
        {
            printf("DIST: VL53L0X not ready\r\n");
        }
    }
    else if (current_page == PAGE_HEALTH)
    {
        PrintHealthData();
        printf("HEALTH: demo estimate only, not for medical use\r\n");
    }
    else if (current_page == PAGE_MOTION_TODO)
    {
        printf("GY-91 slot: I2C driver pending. Planned: posture, tap, lift-up, step estimate.\r\n");
    }
}

static void OledRender(void)
{
    char line[32];

    if (!OLED_IsReady())
    {
        return;
    }

    OLED_PrintLine(0, "WATCHSENSE-F407");

    sprintf(line, "PG:%s", page_names[current_page]);
    OLED_PrintLine(1, line);

    if (current_page == PAGE_DASHBOARD)
    {
        if (vl53_ready && distance_mm != 65535)
        {
            sprintf(line, "DIST:%uMM", distance_mm);
        }
        else
        {
            sprintf(line, "DIST: ----MM");
        }
        OLED_PrintLine(2, line);

        FormatBmeLine(line);
        OLED_PrintLine(3, line);

        FormatPressureLine(line);
        OLED_PrintLine(4, line);

        sprintf(line, "ALM:%s %uMM", alarm_enabled ? "ON" : "OFF",
                alarm_thresholds[threshold_index]);
        OLED_PrintLine(5, line);

        FormatHealthLine(line);
        OLED_PrintLine(6, line);

        sprintf(line, "VL:%s BME:%s MAX:%s",
                vl53_ready ? "OK" : "NO",
                bme_ready ? "OK" : "NO",
                max30102_ready ? "OK" : "NO");
        OLED_PrintLine(7, line);
    }
    else if (current_page == PAGE_ENVIRONMENT)
    {
        FormatBmeLine(line);
        OLED_PrintLine(2, line);
        FormatPressureLine(line);
        OLED_PrintLine(3, line);
        OLED_PrintLine(4, bme_ready ? "BME280: OK" : "BME280: FAIL");
        OLED_PrintLine(5, "SPI1 PA5/6/7 PA4");
        OLED_PrintLine(6, "KEY0 NEXT PAGE");
        OLED_PrintLine(7, "");
    }
    else if (current_page == PAGE_DISTANCE)
    {
        if (vl53_ready && distance_mm != 65535)
        {
            sprintf(line, "DIST:%uMM", distance_mm);
        }
        else
        {
            sprintf(line, "DIST: ----MM");
        }
        OLED_PrintLine(2, line);
        sprintf(line, "TH:%uMM %s", alarm_thresholds[threshold_index],
                alarm_enabled ? "ON" : "OFF");
        OLED_PrintLine(3, line);
        sprintf(line, "OFF:%dMM", (int)VL53L0X_GetOffset());
        OLED_PrintLine(4, line);
        sprintf(line, "MODE:%s", vl_profile_names[profile_index]);
        OLED_PrintLine(5, line);
        OLED_PrintLine(6, "WK_UP CAL 100MM");
        OLED_PrintLine(7, vl53_ready ? "VL53L0X: OK" : "VL53L0X: FAIL");
    }
    else if (current_page == PAGE_HEALTH)
    {
        const MAX30102_Data *data;

        data = MAX30102_GetData();
        FormatHealthLine(line);
        OLED_PrintLine(2, line);

        if (!max30102_ready || !data->ready)
        {
            OLED_PrintLine(3, "MAX30102: FAIL");
            OLED_PrintLine(4, "I2C PB8/PB9");
            OLED_PrintLine(5, "ADDR 0x57");
            OLED_PrintLine(6, "CHECK 3.3V/GND");
            OLED_PrintLine(7, "");
        }
        else
        {
            sprintf(line, "IR:%lu", (unsigned long)data->ir);
            OLED_PrintLine(3, line);
            sprintf(line, "RED:%lu", (unsigned long)data->red);
            OLED_PrintLine(4, line);
            sprintf(line, "BEAT:%u", data->beat_count);
            OLED_PrintLine(5, line);
            OLED_PrintLine(6, data->finger ? "FINGER: YES" : "FINGER: NO");
            OLED_PrintLine(7, "DEMO ESTIMATE");
        }
    }
    else if (current_page == PAGE_MOTION_TODO)
    {
        OLED_PrintLine(2, "GY-91 SLOT");
        OLED_PrintLine(3, "I2C TODO");
        OLED_PrintLine(4, "POSTURE/TAP/LIFT");
        OLED_PrintLine(5, "STEP ESTIMATE");
        OLED_PrintLine(6, "KEY0 NEXT PAGE");
        OLED_PrintLine(7, "");
    }
}

int main(void)
{
    uint32_t now_ms = 0;
    uint32_t last_env_ms = 0;
    uint32_t last_dist_ms = 0;
    uint32_t last_ui_ms = 0;
    uint32_t last_retry_ms = 0;

    Stm32_Clock_Init(336, 8, 2, 7);
    delay_init(168);
    LED_Init();
    BEEP_Init();
    KEY_Init();
    uart_init(84, 115200);
    myI2C_init();

    LED0 = 1;
    LED1 = 1;
    BEEP = 0;

    printf("\r\nWatchSense-F407 desktop station prototype\r\n");
    printf("KEY0 page, KEY1 VL53L0X profile, KEY2 threshold, WK_UP VL53L0X calibration\r\n");
    printf("VL53L0X: PB8/PB9 I2C, PB5 XSHUT\r\n");
    printf("OLED: PB8/PB9 I2C, address 0x3C\r\n");
    printf("BME280: SPI1 PA5=SCK PA6=MISO PA7=MOSI PA4=CS\r\n");
    printf("MAX30102: PB8/PB9 I2C, address 0x57, demo HR/SpO2 estimate\r\n");

    printf("OLED %s\r\n", OLED_Init() ? "OK" : "FAIL");
    if (OLED_IsReady())
    {
        OLED_PrintLine(0, "WATCHSENSE-F407");
        OLED_PrintLine(1, "BOOTING...");
        OLED_PrintLine(2, "OLED OK");
        OLED_PrintLine(3, "SERIAL 115200");
    }

    bme_ready = Bme280StationInit();
    printf("BME280 %s\r\n", bme_ready ? "OK" : "FAIL");

    Vl53StationInit();

    Max30102StationInit();

    printf("Prototype is running. GY-91 remains as the next TODO slot.\r\n");

    while (1)
    {
        HandleKey(KeyScan());
        Max30102Sample(now_ms);

        if ((now_ms - last_env_ms) >= 1000)
        {
            Bme280Sample();
            last_env_ms = now_ms;
        }

        if ((now_ms - last_dist_ms) >= 200)
        {
            Vl53Sample();
            last_dist_ms = now_ms;
        }

        ApplyLinkage();

        if ((now_ms - last_ui_ms) >= 1000)
        {
            OledRender();
            PrintStationFrame();
            LED0 = !LED0;
            last_ui_ms = now_ms;
        }

        if ((now_ms - last_retry_ms) >= 5000)
        {
            RetryFailedSensors();
            last_retry_ms = now_ms;
        }

        delay_ms(20);
        now_ms += 20;
    }
}
