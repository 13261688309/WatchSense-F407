#include "MAX6675.h"

void MAX6675_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;//
	SPI_InitTypeDef  SPI_InitStruct;//
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOA,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1,ENABLE);
	
	//GPIO B ��ʼ��
	  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
	  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
	  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStruct.GPIO_PuPd =GPIO_PuPd_UP ;
	  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;

    GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	//GPIO A ��ʼ��
	  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
	  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStruct.GPIO_PuPd =GPIO_PuPd_UP ;
	  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;

    GPIO_Init(GPIOA, &GPIO_InitStruct);
		
	//����GPIO���� ���ú���
		GPIO_PinAFConfig(GPIOB,GPIO_PinSource3,GPIO_AF_SPI1);
		GPIO_PinAFConfig(GPIOB,GPIO_PinSource4,GPIO_AF_SPI1);
		GPIO_PinAFConfig(GPIOB,GPIO_PinSource5,GPIO_AF_SPI1);
		
		
	//SPI ��ʼ��
	  SPI_InitStruct.SPI_Direction =SPI_Direction_2Lines_FullDuplex;
		SPI_InitStruct.SPI_Mode =SPI_Mode_Master;
		SPI_InitStruct.SPI_DataSize =SPI_DataSize_16b ;
		SPI_InitStruct.SPI_CPOL =SPI_CPOL_Low;
		SPI_InitStruct.SPI_CPHA =SPI_CPHA_2Edge;
		SPI_InitStruct.SPI_NSS  =SPI_NSS_Soft;
		SPI_InitStruct.SPI_BaudRatePrescaler  =SPI_BaudRatePrescaler_16;
		SPI_InitStruct.SPI_FirstBit  =SPI_FirstBit_MSB;
		SPI_InitStruct.SPI_CRCPolynomial  =2;
	
		SPI_Init(SPI1,&SPI_InitStruct);
    SPI_Cmd(SPI1, ENABLE);
		SPI1_ReadWriteByte(0xff);
}

u16 SPI1_ReadWriteByte(u16 TxData)
{
    while (SPI_I2S_GetFlagStatus(SPI1 ,SPI_I2S_FLAG_TXE)==RESET)
    {}SPI_I2S_SendData(SPI1,TxData);
    while (SPI_I2S_GetFlagStatus(SPI1 ,SPI_I2S_FLAG_RXNE)==RESET)
    { } 
    return SPI_I2S_ReceiveData(SPI1);
}
u16 MAX6675_ReadByte(void)
{
    u16 i;
	CS=0;
	i=SPI1_ReadWriteByte(0xff);  
    CS=1;
    return i;
}

