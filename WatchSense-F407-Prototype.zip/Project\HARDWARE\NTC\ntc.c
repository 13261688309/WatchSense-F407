#include "ntc.h"

void NTC_Init(void)
{    	 
	GPIO_InitTypeDef GPIO_InitStruct;
	 RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF,ENABLE);
	
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;

	GPIO_InitStruct.GPIO_PuPd =GPIO_PuPd_DOWN ;

	GPIO_Init(GPIOF, &GPIO_InitStruct);
}

