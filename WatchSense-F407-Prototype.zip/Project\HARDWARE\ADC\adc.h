#ifndef __ADC_H
#define __ADC_H	 
#include "sys.h" 

//#define  ADC_Init(ADC1, &ADC_InitStruct)
//#define  ADC_StructInit(&ADC_InitStruct)
void myadc_Init(void);
u16 GET_ADC(u8 ch);
u16 Get_ADC_Average(u8 ch,u8 times);
#endif

