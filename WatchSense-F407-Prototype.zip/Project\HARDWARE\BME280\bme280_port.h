#ifndef __BME280_PORT_H
#define __BME280_PORT_H

#include "sys.h"
#include "bme280.h"

void BME280_SPI_Init(void);
void BME280_CS_Low(void);
void BME280_CS_High(void);
uint8_t BME280_SPI_ReadWriteByte(uint8_t tx_data);

BME280_INTF_RET_TYPE user_spi_read(uint8_t reg_addr, uint8_t *reg_data, uint32_t len, void *intf_ptr);
BME280_INTF_RET_TYPE user_spi_write(uint8_t reg_addr, const uint8_t *reg_data, uint32_t len, void *intf_ptr);
void user_delay_us(uint32_t period, void *intf_ptr);

#endif
