VL53L0X STM32F407ZGT6 standard peripheral demo

Wiring:
- VIN   -> 3.3V
- GND   -> GND
- SCL   -> PB8
- SDA   -> PB9
- XSHUT -> PB5
- GPIO1 -> not used
- BEEP  -> PF8, on-board buzzer
- LED0  -> PF9, running indicator
- LED1  -> PF10, alarm/error indicator
- KEY0  -> PE4, change alarm threshold
- KEY1  -> PE3, change ranging profile
- KEY2  -> PE2, alarm enable/disable
- WK_UP -> PA0, offset calibration

Serial output:
- USART1, 115200 bps
- Prints init status, VL53L0X model/revision ID, timing budget, profile, offset, threshold, and distance every 200 ms.

LED status:
- LED0 toggles while the program is running.
- LED1 lights on init failure or ranging timeout.
- LED1 also lights when the measured distance is below the alarm threshold.

Advanced features:
- KEY0 cycles the alarm threshold: 80 mm, 150 mm, 300 mm, 600 mm.
- KEY1 cycles ranging profiles:
  - default: balanced mode.
  - speed: 20 ms timing budget for faster response.
  - accuracy: 200 ms timing budget for lower noise.
  - long: lower signal limit plus longer VCSEL pulses for more range.
- KEY2 toggles the BEEP/LED alarm linkage.
- WK_UP runs offset calibration against a 100 mm reference target.

Calibration:
- Put a flat, light-colored target 100 mm from the VL53L0X front face.
- Press WK_UP and keep the target still until the serial port prints "Calibration OK".
- The code averages 20 single-shot samples and stores offset = 100 mm - average_raw_distance.
- The offset is RAM-only; restart or power loss resets it to 0 mm.
- If calibration fails, check target angle, distance, ambient light, and I2C wiring.

Keil project:
- Open USER/TEST.uvprojx.
- The VL53L0X driver is in HARDWARE/VL53L0X.
- The software I2C driver is in HARDWARE/I2C.

Troubleshooting:
- A good VL53L0X model ID read is 0xEE.
- If init fails with last I2C status 1, check pull-ups, PB8/PB9 wiring, power, and XSHUT on PB5.

Merged prototype:
- See WATCHSENSE_PROTOTYPE_README.txt for the desktop station firmware.
- See WATCHSENSE_WIRING_GUIDE.txt for the current combined wiring of VL53L0X, BME280, OLED, MAX30102, and the reserved GY-91 slot.
