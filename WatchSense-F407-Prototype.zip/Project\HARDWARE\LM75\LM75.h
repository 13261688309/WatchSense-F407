#ifndef __LM75_H
#define __LM75_H	 
#include "sys.h" 
#include "I2C.h"
void LM75A_Write_Byte(u8 addr);
void LM75A_Read_Byte(u8 addr);
void LM75_Read_Temp(float *dat);
#endif

