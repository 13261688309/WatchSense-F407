#ifndef _EXTIX_H
#define _EXTIX_H
#include "key.h"
#include "sys.h"
#include "led.h"
#include "delay.h"
#include "beep.h"
#include "usart.h"
void EXTIX_Init(void);

#endif

