#include "I2C.h"
#include "delay.h"

static void I2C_Delay(void)
{
    delay_us(3);
}

void I2C_BusRecover(void)
{
    u8 i;

    SDA_OUT();
    SDA = 1;
    SCL = 1;
    I2C_Delay();

    for (i = 0; i < 9; i++)
    {
        SCL = 0;
        I2C_Delay();
        SCL = 1;
        I2C_Delay();

        if (READ_SDA)
        {
            break;
        }
    }

    Stop();
}

void myI2C_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    RCC_AHB1PeriphClockCmd(I2C_PORT_CLK, ENABLE);

    GPIO_InitStruct.GPIO_Pin = I2C_SCL_PIN | I2C_SDA_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(I2C_PORT, &GPIO_InitStruct);

    SCL = 1;
    SDA = 1;
    I2C_BusRecover();
}

void Start(void)
{
    SDA_OUT();
    SDA = 1;
    SCL = 1;
    I2C_Delay();
    SDA = 0;
    I2C_Delay();
    SCL = 0;
    I2C_Delay();
}

void Stop(void)
{
    SDA_OUT();
    SCL = 0;
    SDA = 0;
    I2C_Delay();
    SCL = 1;
    I2C_Delay();
    SDA = 1;
    I2C_Delay();
}

void Ack(void)
{
    SDA_OUT();
    SCL = 0;
    SDA = 0;
    I2C_Delay();
    SCL = 1;
    I2C_Delay();
    SCL = 0;
    I2C_Delay();
}

u8 Wait_Ack(void)
{
    u16 timeout = 0;

    SDA_IN();
    SDA = 1;
    I2C_Delay();
    SCL = 1;
    I2C_Delay();

    while (READ_SDA)
    {
        timeout++;
        if (timeout > 250)
        {
            Stop();
            return 1;
        }
        delay_us(1);
    }

    SCL = 0;
    I2C_Delay();
    return 0;
}

void Nack(void)
{
    SDA_OUT();
    SCL = 0;
    SDA = 1;
    I2C_Delay();
    SCL = 1;
    I2C_Delay();
    SCL = 0;
    I2C_Delay();
}

void Send_Byte(u8 txd)
{
    u8 i;

    SDA_OUT();
    SCL = 0;
    for (i = 0; i < 8; i++)
    {
        SDA = (txd & 0x80) ? 1 : 0;
        txd <<= 1;
        I2C_Delay();
        SCL = 1;
        I2C_Delay();
        SCL = 0;
        I2C_Delay();
    }
}

u8 Read_Byte(unsigned char ack)
{
    u8 i;
    u8 receive = 0;

    SDA_IN();
    for (i = 0; i < 8; i++)
    {
        SCL = 0;
        I2C_Delay();
        SCL = 1;
        receive <<= 1;
        if (READ_SDA)
        {
            receive++;
        }
        I2C_Delay();
    }

    if (ack)
    {
        Ack();
    }
    else
    {
        Nack();
    }

    return receive;
}

u8 i2c_write(u8 addr_7bit, const u8 *buf, u16 len)
{
    u16 i;

    Start();
    Send_Byte((addr_7bit << 1) | 0x00);
    if (Wait_Ack())
    {
        Stop();
        return 1;
    }

    for (i = 0; i < len; i++)
    {
        Send_Byte(buf[i]);
        if (Wait_Ack())
        {
            Stop();
            return 1;
        }
    }

    Stop();
    return 0;
}

u8 i2c_read(u8 addr_7bit, u8 *buf, u16 len)
{
    u16 i;

    if (len == 0)
    {
        return 0;
    }

    Start();
    Send_Byte((addr_7bit << 1) | 0x01);
    if (Wait_Ack())
    {
        Stop();
        return 1;
    }

    for (i = 0; i < len; i++)
    {
        buf[i] = Read_Byte(i < (len - 1));
    }

    Stop();
    return 0;
}

u8 I2C_WriteReg(u8 addr_7bit, u8 reg, u8 data)
{
    u8 buf[2];

    buf[0] = reg;
    buf[1] = data;
    return i2c_write(addr_7bit, buf, 2);
}

u8 I2C_WriteMulti(u8 addr_7bit, u8 reg, const u8 *buf, u16 len)
{
    u16 i;

    Start();
    Send_Byte((addr_7bit << 1) | 0x00);
    if (Wait_Ack())
    {
        Stop();
        return 1;
    }

    Send_Byte(reg);
    if (Wait_Ack())
    {
        Stop();
        return 1;
    }

    for (i = 0; i < len; i++)
    {
        Send_Byte(buf[i]);
        if (Wait_Ack())
        {
            Stop();
            return 1;
        }
    }

    Stop();
    return 0;
}

u8 I2C_ReadReg(u8 addr_7bit, u8 reg, u8 *data)
{
    return I2C_ReadMulti(addr_7bit, reg, data, 1);
}

u8 I2C_ReadMulti(u8 addr_7bit, u8 reg, u8 *buf, u16 len)
{
    u16 i;

    if (len == 0)
    {
        return 0;
    }

    Start();
    Send_Byte((addr_7bit << 1) | 0x00);
    if (Wait_Ack())
    {
        Stop();
        return 1;
    }

    Send_Byte(reg);
    if (Wait_Ack())
    {
        Stop();
        return 1;
    }

    Start();
    Send_Byte((addr_7bit << 1) | 0x01);
    if (Wait_Ack())
    {
        Stop();
        return 1;
    }

    for (i = 0; i < len; i++)
    {
        buf[i] = Read_Byte(i < (len - 1));
    }

    Stop();
    return 0;
}
