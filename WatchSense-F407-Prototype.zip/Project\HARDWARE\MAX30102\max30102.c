#include "max30102.h"
#include "I2C.h"
#include "delay.h"
#include <string.h>

#define REG_INT_STATUS1        0x00
#define REG_INT_STATUS2        0x01
#define REG_INT_ENABLE1        0x02
#define REG_INT_ENABLE2        0x03
#define REG_FIFO_WR_PTR        0x04
#define REG_OVF_COUNTER        0x05
#define REG_FIFO_RD_PTR        0x06
#define REG_FIFO_DATA          0x07
#define REG_FIFO_CONFIG        0x08
#define REG_MODE_CONFIG        0x09
#define REG_SPO2_CONFIG        0x0A
#define REG_LED1_PA            0x0C
#define REG_LED2_PA            0x0D
#define REG_TEMP_CONFIG        0x21
#define REG_REV_ID             0xFE
#define REG_PART_ID            0xFF

#define FINGER_IR_THRESHOLD    50000UL
#define SPO2_WINDOW_SAMPLES    200
#define MAX_FIFO_DRAIN         12

static MAX30102_Data g_max30102;
static uint32_t red_min;
static uint32_t red_max;
static uint32_t ir_min;
static uint32_t ir_max;
static u16 window_count;
static int32_t prev2_ac;
static int32_t prev_ac;

static u8 max30102_write_reg(u8 reg, u8 data)
{
    return I2C_WriteReg(MAX30102_I2C_ADDR, reg, data);
}

static u8 max30102_read_reg(u8 reg, u8 *data)
{
    return I2C_ReadReg(MAX30102_I2C_ADDR, reg, data);
}

static u8 max30102_read_multi(u8 reg, u8 *buf, u16 len)
{
    return I2C_ReadMulti(MAX30102_I2C_ADDR, reg, buf, len);
}

static int32_t iabs32(int32_t value)
{
    return value < 0 ? -value : value;
}

static u8 max30102_clear_fifo(void)
{
    if (!max30102_write_reg(REG_FIFO_WR_PTR, 0x00))
    {
        return 0;
    }
    if (!max30102_write_reg(REG_OVF_COUNTER, 0x00))
    {
        return 0;
    }
    if (!max30102_write_reg(REG_FIFO_RD_PTR, 0x00))
    {
        return 0;
    }
    return 1;
}

static void max30102_reset_state(void)
{
    memset(&g_max30102, 0, sizeof(g_max30102));
    red_min = 0xFFFFFFFFUL;
    ir_min = 0xFFFFFFFFUL;
    red_max = 0;
    ir_max = 0;
    window_count = 0;
    prev2_ac = 0;
    prev_ac = 0;
}

static void max30102_update_spo2(void)
{
    uint32_t red_ac;
    uint32_t ir_ac;
    uint32_t ratio_x100;
    int32_t spo2;

    if (red_max <= red_min || ir_max <= ir_min || g_max30102.red_dc <= 0 || g_max30102.ir_dc <= 0)
    {
        g_max30102.spo2_valid = 0;
        return;
    }

    red_ac = red_max - red_min;
    ir_ac = ir_max - ir_min;
    if (red_ac == 0 || ir_ac == 0)
    {
        g_max30102.spo2_valid = 0;
        return;
    }

    ratio_x100 = (uint32_t)(((uint64_t)red_ac * (uint32_t)g_max30102.ir_dc * 100ULL) /
                            ((uint64_t)ir_ac * (uint32_t)g_max30102.red_dc));
    spo2 = 110 - (int32_t)((25UL * ratio_x100) / 100UL);
    if (spo2 > 100)
    {
        spo2 = 100;
    }
    if (spo2 < 70)
    {
        spo2 = 70;
    }

    g_max30102.spo2 = (u8)spo2;
    g_max30102.spo2_valid = 1;
}

static void max30102_process_sample(uint32_t red, uint32_t ir, uint32_t now_ms)
{
    int32_t red_delta;
    int32_t ir_delta;
    int32_t threshold;
    uint32_t interval;
    uint32_t bpm;

    g_max30102.red = red;
    g_max30102.ir = ir;
    g_max30102.sample_count++;
    g_max30102.finger = (ir > FINGER_IR_THRESHOLD) ? 1 : 0;

    if (!g_max30102.finger)
    {
        g_max30102.bpm = 0;
        g_max30102.spo2_valid = 0;
        g_max30102.beat_count = 0;
        g_max30102.last_beat_ms = 0;
        g_max30102.ir_dc = (int32_t)ir;
        g_max30102.red_dc = (int32_t)red;
        g_max30102.ir_ac = 0;
        g_max30102.ac_abs_avg = 0;
        prev2_ac = 0;
        prev_ac = 0;
        red_min = 0xFFFFFFFFUL;
        ir_min = 0xFFFFFFFFUL;
        red_max = 0;
        ir_max = 0;
        window_count = 0;
        return;
    }

    if (g_max30102.ir_dc == 0)
    {
        g_max30102.ir_dc = (int32_t)ir;
        g_max30102.red_dc = (int32_t)red;
    }

    ir_delta = (int32_t)ir - g_max30102.ir_dc;
    red_delta = (int32_t)red - g_max30102.red_dc;
    g_max30102.ir_dc += ir_delta / 32;
    g_max30102.red_dc += red_delta / 32;
    g_max30102.ir_ac = (int32_t)ir - g_max30102.ir_dc;
    g_max30102.ac_abs_avg += (iabs32(g_max30102.ir_ac) - g_max30102.ac_abs_avg) / 16;

    threshold = g_max30102.ac_abs_avg * 2;
    if (threshold < 1000)
    {
        threshold = 1000;
    }

    if (prev_ac > prev2_ac && prev_ac > g_max30102.ir_ac && prev_ac > threshold)
    {
        if (g_max30102.last_beat_ms != 0)
        {
            interval = now_ms - g_max30102.last_beat_ms;
            if (interval >= 300 && interval <= 2000)
            {
                bpm = 60000UL / interval;
                if (g_max30102.bpm == 0)
                {
                    g_max30102.bpm = (u16)bpm;
                }
                else
                {
                    g_max30102.bpm = (u16)(((uint32_t)g_max30102.bpm * 3UL + bpm) / 4UL);
                }
                g_max30102.beat_count++;
            }
        }
        g_max30102.last_beat_ms = now_ms;
    }

    prev2_ac = prev_ac;
    prev_ac = g_max30102.ir_ac;

    if (red < red_min)
    {
        red_min = red;
    }
    if (red > red_max)
    {
        red_max = red;
    }
    if (ir < ir_min)
    {
        ir_min = ir;
    }
    if (ir > ir_max)
    {
        ir_max = ir;
    }

    window_count++;
    if (window_count >= SPO2_WINDOW_SAMPLES)
    {
        max30102_update_spo2();
        red_min = 0xFFFFFFFFUL;
        ir_min = 0xFFFFFFFFUL;
        red_max = 0;
        ir_max = 0;
        window_count = 0;
    }
}

u8 MAX30102_GetPartID(void)
{
    u8 part_id = 0;

    if (!max30102_read_reg(REG_PART_ID, &part_id))
    {
        return 0;
    }
    return part_id;
}

u8 MAX30102_Init(void)
{
    u8 part_id;
    u8 dummy;

    max30102_reset_state();

    if (!max30102_read_reg(REG_PART_ID, &part_id))
    {
        return 0;
    }

    g_max30102.part_id = part_id;
    if (part_id != MAX30102_EXPECTED_ID)
    {
        return 0;
    }

    if (!max30102_write_reg(REG_MODE_CONFIG, 0x40))
    {
        return 0;
    }
    delay_ms(100);

    if (!max30102_read_reg(REG_PART_ID, &part_id) || part_id != MAX30102_EXPECTED_ID)
    {
        return 0;
    }
    g_max30102.part_id = part_id;

    if (!max30102_clear_fifo())
    {
        return 0;
    }
    if (!max30102_write_reg(REG_INT_ENABLE1, 0xC0) ||
        !max30102_write_reg(REG_INT_ENABLE2, 0x00) ||
        !max30102_write_reg(REG_FIFO_CONFIG, 0x5F) ||
        !max30102_write_reg(REG_MODE_CONFIG, 0x03) ||
        !max30102_write_reg(REG_SPO2_CONFIG, 0x27) ||
        !max30102_write_reg(REG_LED1_PA, 0x24) ||
        !max30102_write_reg(REG_LED2_PA, 0x24))
    {
        return 0;
    }
    if (!max30102_read_reg(REG_INT_STATUS1, &dummy) ||
        !max30102_read_reg(REG_INT_STATUS2, &dummy))
    {
        return 0;
    }

    g_max30102.ready = 1;
    return 1;
}

void MAX30102_Shutdown(void)
{
    if (g_max30102.ready)
    {
        max30102_write_reg(REG_MODE_CONFIG, 0x80);
    }
    g_max30102.ready = 0;
}

u8 MAX30102_Available(void)
{
    u8 wr = 0;
    u8 rd = 0;

    if (!max30102_read_reg(REG_FIFO_WR_PTR, &wr) || !max30102_read_reg(REG_FIFO_RD_PTR, &rd))
    {
        g_max30102.ready = 0;
        return 0;
    }

    return (wr - rd) & 0x1F;
}

u8 MAX30102_ReadFIFO(uint32_t *red, uint32_t *ir)
{
    u8 buf[6];

    if (!max30102_read_multi(REG_FIFO_DATA, buf, 6))
    {
        g_max30102.ready = 0;
        return 0;
    }

    *red = (((uint32_t)buf[0] << 16) | ((uint32_t)buf[1] << 8) | buf[2]) & 0x03FFFFUL;
    *ir = (((uint32_t)buf[3] << 16) | ((uint32_t)buf[4] << 8) | buf[5]) & 0x03FFFFUL;
    return 1;
}

u8 MAX30102_Task(uint32_t now_ms, MAX30102_Data *out)
{
    u8 available;
    u8 count;
    u8 processed = 0;
    uint32_t sample_ms;
    uint32_t span_ms;
    uint32_t red;
    uint32_t ir;

    if (!g_max30102.ready)
    {
        return 0;
    }

    available = MAX30102_Available();
    count = available;
    if (count > MAX_FIFO_DRAIN)
    {
        count = MAX_FIFO_DRAIN;
    }
    sample_ms = now_ms;
    if (count > 1)
    {
        span_ms = (uint32_t)(count - 1) * 10UL;
        sample_ms = (now_ms > span_ms) ? (now_ms - span_ms) : 0;
    }

    while (count > 0)
    {
        if (!MAX30102_ReadFIFO(&red, &ir))
        {
            break;
        }
        max30102_process_sample(red, ir, sample_ms);
        sample_ms += 10UL;
        processed++;
        count--;
    }

    if (available > 28)
    {
        if (!max30102_clear_fifo())
        {
            g_max30102.ready = 0;
        }
    }

    if (out != 0)
    {
        *out = g_max30102;
    }

    return processed;
}

const MAX30102_Data *MAX30102_GetData(void)
{
    return &g_max30102;
}
