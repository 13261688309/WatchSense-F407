#include "sys.h"
#include "delay.h"
#include "led.h"
#include "beep.h"
#include "key.h"
#include "usart.h"
#include "I2C.h"
#include "VL53L0X.h"
#include "bme280_port.h"
#include "oled.h"
#include "max30102.h"
#include "mpu9250.h"
#include <stdio.h>

#define KEY_NONE        0
#define KEY0_PRESS      1
#define KEY1_PRESS      2
#define KEY2_PRESS      3
#define WKUP_PRESS      4

#define CAL_TARGET_MM   100

typedef enum
{
    PAGE_DASHBOARD = 0,
    PAGE_ENVIRONMENT,
    PAGE_DISTANCE,
    PAGE_HEALTH,
    PAGE_MOTION,
    PAGE_COUNT
} StationPage;

static const u16 alarm_thresholds[] = {80, 150, 300, 600};
static const enum VL53L0X_Profile vl_profiles[] =
{
    VL53L0X_PROFILE_DEFAULT,
    VL53L0X_PROFILE_HIGH_SPEED,
    VL53L0X_PROFILE_HIGH_ACCURACY,
    VL53L0X_PROFILE_LONG_RANGE
};
static const char *vl_profile_names[] =
{
    "default",
    "speed",
    "accuracy",
    "long"
};
static const char *page_names[] =
{
    "dashboard",
    "environment",
    "distance",
    "health",
    "motion"
};

static struct bme280_dev bme_dev;
static struct bme280_settings bme_settings;
static struct bme280_data bme_data;
static uint32_t bme_meas_delay_us;
static u8 bme_ready;
static u8 vl53_ready;
static u8 max30102_ready;
static u8 imu_ready;
static u8 imu_mag_ready;
static u8 imu_calibrated;
static u16 distance_mm = 65535;
static u8 alarm_enabled = 1;
static u8 threshold_index = 1;
static u8 profile_index = 0;
static StationPage current_page = PAGE_DASHBOARD;
static MPU9250_Data imu_data;
static s32 imu_gyro_bias_x100[3];
static u32 motion_step_count;
static u16 motion_tap_count;
static u16 motion_lift_count;
static u8 motion_step_armed = 1;
static u32 motion_last_step_ms;
static u32 motion_last_tap_ms;
static u32 motion_last_lift_ms;
static u32 motion_alert_until_ms;
static u32 motion_last_accel_mag_mg = 1000;

static u8 KeyScan(void)
{
    u8 raw_key = KEY_NONE;
    static u8 last_raw_key = KEY_NONE;
    static u8 reported_key = KEY_NONE;
    static u8 stable_count = 0;

    if (KEY0 == 0)
    {
        raw_key = KEY0_PRESS;
    }
    else if (KEY1 == 0)
    {
        raw_key = KEY1_PRESS;
    }
    else if (KEY2 == 0)
    {
        raw_key = KEY2_PRESS;
    }
    else if (WK_UP == 1)
    {
        raw_key = WKUP_PRESS;
    }

    if (raw_key == last_raw_key)
    {
        if (stable_count < 3)
        {
            stable_count++;
        }
    }
    else
    {
        last_raw_key = raw_key;
        stable_count = 0;
    }

    if (stable_count < 2)
    {
        return KEY_NONE;
    }

    if (raw_key == KEY_NONE)
    {
        reported_key = KEY_NONE;
        return KEY_NONE;
    }

    if (reported_key != raw_key)
    {
        reported_key = raw_key;
        return raw_key;
    }

    return KEY_NONE;
}

static void PrintBmeResult(const char *api_name, int8_t rslt)
{
    if (rslt != BME280_OK)
    {
        printf("%s failed, code: %d\r\n", api_name, rslt);
    }
}

static void PrintBmeData(void)
{
    long temp_int;
    long temp_frac;
    unsigned long hum_int;
    unsigned long hum_frac;
    unsigned long press_int;
    unsigned long press_frac;

    if (!bme_ready)
    {
        printf("ENV: BME280 not ready\r\n");
        return;
    }

    temp_int = bme_data.temperature / 100;
    temp_frac = bme_data.temperature % 100;
    if (temp_frac < 0)
    {
        temp_frac = -temp_frac;
    }

    hum_int = bme_data.humidity / 1024;
    hum_frac = ((bme_data.humidity % 1024) * 100) / 1024;

    press_int = bme_data.pressure / 100;
    press_frac = bme_data.pressure % 100;

    printf("ENV: T=%ld.%02ld C, RH=%lu.%02lu %%, P=%lu.%02lu Pa\r\n",
           temp_int,
           temp_frac,
           hum_int,
           hum_frac,
           press_int,
           press_frac);
}

static void FormatBmeLine(char *line)
{
    long temp_int;
    long temp_frac;
    unsigned long hum_int;
    unsigned long hum_frac;

    if (!bme_ready)
    {
        sprintf(line, "ENV: --.-C --.-%%");
        return;
    }

    temp_int = bme_data.temperature / 100;
    temp_frac = bme_data.temperature % 100;
    if (temp_frac < 0)
    {
        temp_frac = -temp_frac;
    }

    hum_int = bme_data.humidity / 1024;
    hum_frac = ((bme_data.humidity % 1024) * 10) / 1024;

    sprintf(line, "ENV:%ld.%02ldC %lu.%lu%%",
            temp_int, temp_frac, hum_int, hum_frac);
}

static void FormatPressureLine(char *line)
{
    unsigned long press_hpa_int;
    unsigned long press_hpa_frac;

    if (!bme_ready)
    {
        sprintf(line, "AIR: ----.-hPa");
        return;
    }

    press_hpa_int = bme_data.pressure / 10000;
    press_hpa_frac = (bme_data.pressure % 10000) / 1000;

    sprintf(line, "AIR:%lu.%luhPa", press_hpa_int, press_hpa_frac);
}

static void FormatHealthLine(char *line)
{
    const MAX30102_Data *data;

    data = MAX30102_GetData();
    if (!max30102_ready || !data->ready)
    {
        sprintf(line, "HR:-- SPO2:--");
        return;
    }

    if (!data->finger)
    {
        sprintf(line, "HR:NO FINGER");
        return;
    }

    if (data->bpm > 0 && data->spo2_valid)
    {
        sprintf(line, "HR:%u SPO2:%u%%", data->bpm, data->spo2);
    }
    else if (data->bpm > 0)
    {
        sprintf(line, "HR:%u SPO2:..", data->bpm);
    }
    else
    {
        sprintf(line, "HR:... SPO2:..");
    }
}

static s32 Abs32(s32 value)
{
    return (value < 0) ? -value : value;
}

static u32 Isqrt32(u32 value)
{
    u32 bit = 1UL << 30;
    u32 result = 0;

    while (bit > value)
    {
        bit >>= 2;
    }

    while (bit != 0)
    {
        if (value >= result + bit)
        {
            value -= result + bit;
            result = (result >> 1) + bit;
        }
        else
        {
            result >>= 1;
        }
        bit >>= 2;
    }

    return result;
}

static u32 MotionAccelMagnitudeMg(const MPU9250_Data *data)
{
    s32 ax;
    s32 ay;
    s32 az;
    u32 sum;

    ax = data->accel_mg[0];
    ay = data->accel_mg[1];
    az = data->accel_mg[2];
    sum = (u32)(ax * ax + ay * ay + az * az);

    return Isqrt32(sum);
}

static const char *MotionPostureName(void)
{
    s32 ax;
    s32 ay;
    s32 az;
    s32 aax;
    s32 aay;
    s32 aaz;

    if (!imu_ready)
    {
        return "NO";
    }

    ax = imu_data.accel_mg[0];
    ay = imu_data.accel_mg[1];
    az = imu_data.accel_mg[2];
    aax = Abs32(ax);
    aay = Abs32(ay);
    aaz = Abs32(az);

    if (aaz >= aax && aaz >= aay)
    {
        return (az >= 0) ? "FLAT" : "DOWN";
    }
    if (aax >= aay)
    {
        return (ax >= 0) ? "RIGHT" : "LEFT";
    }

    return (ay >= 0) ? "UP" : "WRIST";
}

static const char *MotionHeadingName(void)
{
    s32 mx;
    s32 my;
    s32 amx;
    s32 amy;

    if (!imu_ready || !imu_mag_ready)
    {
        return "--";
    }

    mx = imu_data.mag_ut_x100[0];
    my = imu_data.mag_ut_x100[1];
    amx = Abs32(mx);
    amy = Abs32(my);

    if (amx > (amy * 2))
    {
        return (mx >= 0) ? "E" : "W";
    }
    if (amy > (amx * 2))
    {
        return (my >= 0) ? "N" : "S";
    }
    if (mx >= 0 && my >= 0)
    {
        return "NE";
    }
    if (mx >= 0 && my < 0)
    {
        return "SE";
    }
    if (mx < 0 && my >= 0)
    {
        return "NW";
    }
    return "SW";
}

static void FormatMotionLine(char *line)
{
    if (!imu_ready)
    {
        sprintf(line, "MOTION: FAIL");
        return;
    }

    sprintf(line, "POST:%s STEP:%lu", MotionPostureName(),
            (unsigned long)motion_step_count);
}

static void PrintHealthData(void)
{
    const MAX30102_Data *data;

    data = MAX30102_GetData();
    if (!max30102_ready || !data->ready)
    {
        printf("HEALTH: MAX30102 not ready\r\n");
        return;
    }

    if (!data->finger)
    {
        printf("HEALTH: no finger, IR=%lu RED=%lu\r\n",
               (unsigned long)data->ir,
               (unsigned long)data->red);
        return;
    }

    if (data->spo2_valid)
    {
        printf("HEALTH: HR=%u bpm, SpO2=%u%%, IR=%lu, RED=%lu, beats=%u\r\n",
               data->bpm,
               data->spo2,
               (unsigned long)data->ir,
               (unsigned long)data->red,
               data->beat_count);
    }
    else
    {
        printf("HEALTH: HR=%u bpm, SpO2=pending, IR=%lu, RED=%lu, beats=%u\r\n",
               data->bpm,
               (unsigned long)data->ir,
               (unsigned long)data->red,
               data->beat_count);
    }
}

static u8 Bme280StationInit(void)
{
    int8_t rslt;

    BME280_SPI_Init();

    bme_dev.intf = BME280_SPI_INTF;
    bme_dev.read = user_spi_read;
    bme_dev.write = user_spi_write;
    bme_dev.delay_us = user_delay_us;
    bme_dev.intf_ptr = 0;
    bme_dev.intf_rslt = BME280_INTF_RET_SUCCESS;

    rslt = bme280_init(&bme_dev);
    PrintBmeResult("bme280_init", rslt);
    if (rslt != BME280_OK)
    {
        return 0;
    }

    rslt = bme280_get_sensor_settings(&bme_settings, &bme_dev);
    PrintBmeResult("bme280_get_sensor_settings", rslt);
    if (rslt != BME280_OK)
    {
        return 0;
    }

    bme_settings.osr_h = BME280_OVERSAMPLING_1X;
    bme_settings.osr_p = BME280_OVERSAMPLING_1X;
    bme_settings.osr_t = BME280_OVERSAMPLING_1X;
    bme_settings.filter = BME280_FILTER_COEFF_2;
    bme_settings.standby_time = BME280_STANDBY_TIME_1000_MS;

    rslt = bme280_set_sensor_settings(BME280_SEL_ALL_SETTINGS, &bme_settings, &bme_dev);
    PrintBmeResult("bme280_set_sensor_settings", rslt);
    if (rslt != BME280_OK)
    {
        return 0;
    }

    rslt = bme280_cal_meas_delay(&bme_meas_delay_us, &bme_settings);
    PrintBmeResult("bme280_cal_meas_delay", rslt);
    return (rslt == BME280_OK);
}

static void Bme280Sample(void)
{
    int8_t rslt;

    if (!bme_ready)
    {
        return;
    }

    rslt = bme280_set_sensor_mode(BME280_POWERMODE_FORCED, &bme_dev);
    PrintBmeResult("bme280_set_sensor_mode", rslt);
    if (rslt != BME280_OK)
    {
        bme_ready = 0;
        return;
    }

    bme_dev.delay_us(bme_meas_delay_us, bme_dev.intf_ptr);

    rslt = bme280_get_sensor_data(BME280_ALL, &bme_data, &bme_dev);
    PrintBmeResult("bme280_get_sensor_data", rslt);
    if (rslt != BME280_OK)
    {
        bme_ready = 0;
    }
}

static void Vl53StationInit(void)
{
    if (vl53_ready)
    {
        VL53L0X_StopContinuous();
    }

    vl53_ready = VL53L0X_Init();
    if (!vl53_ready)
    {
        printf("VL53L0X failed. I2C status=%u, model=0x%02X\r\n",
               VL53L0X_GetLastStatus(), VL53L0X_GetModelID());
        return;
    }

    VL53L0X_ApplyProfile(vl_profiles[profile_index]);
    VL53L0X_StartContinuous(0);
    printf("VL53L0X OK. profile=%s, timing=%lu us\r\n",
           vl_profile_names[profile_index], VL53L0X_GetMeasurementTimingBudget());
}

static void Max30102StationInit(void)
{
    max30102_ready = MAX30102_Init();
    if (!max30102_ready)
    {
        printf("MAX30102 failed. part_id=0x%02X, expected=0x%02X\r\n",
               MAX30102_GetPartID(), MAX30102_EXPECTED_ID);
        return;
    }

    printf("MAX30102 OK. addr=0x%02X, part_id=0x%02X\r\n",
           MAX30102_I2C_ADDR, MAX30102_GetData()->part_id);
}

static void MotionResetCounters(void)
{
    motion_step_count = 0;
    motion_tap_count = 0;
    motion_lift_count = 0;
    motion_step_armed = 1;
    motion_last_step_ms = 0;
    motion_last_tap_ms = 0;
    motion_last_lift_ms = 0;
    motion_alert_until_ms = 0;
    motion_last_accel_mag_mg = 1000;
}

static u8 MotionCalibrate(u8 samples)
{
    s32 sum_gyro[3] = {0, 0, 0};
    MPU9250_Data sample;
    u8 count = 0;
    u8 index;
    u8 axis;

    if (!imu_ready)
    {
        return 0;
    }

    if (samples == 0)
    {
        samples = 1;
    }

    printf("MPU9250 keep still, calibrating %u samples...\r\n", samples);
    for (index = 0; index < samples; index++)
    {
        if (MPU9250_ReadData(&sample) == MPU9250_OK)
        {
            for (axis = 0; axis < 3; axis++)
            {
                sum_gyro[axis] += sample.gyro_dps_x100[axis];
            }
            imu_data = sample;
            count++;
        }
        delay_ms(5);
    }

    if (count == 0)
    {
        imu_calibrated = 0;
        return 0;
    }

    for (axis = 0; axis < 3; axis++)
    {
        imu_gyro_bias_x100[axis] = sum_gyro[axis] / count;
    }

    imu_mag_ready = MPU9250_MagIsReady();
    imu_calibrated = 1;
    motion_last_accel_mag_mg = MotionAccelMagnitudeMg(&imu_data);

    printf("MPU9250 calibration OK. gyro bias=%ld.%02ld,%ld.%02ld,%ld.%02ld dps\r\n",
           imu_gyro_bias_x100[0] / 100, Abs32(imu_gyro_bias_x100[0] % 100),
           imu_gyro_bias_x100[1] / 100, Abs32(imu_gyro_bias_x100[1] % 100),
           imu_gyro_bias_x100[2] / 100, Abs32(imu_gyro_bias_x100[2] % 100));

    return 1;
}

static void MotionStationInit(void)
{
    MPU9250_Config config;
    u8 id = 0;
    u8 mag_id = 0;
    u8 result;

    MPU9250_GetDefaultConfig(&config);
    config.accel_range = MPU9250_ACCEL_RANGE_4G;
    config.gyro_range = MPU9250_GYRO_RANGE_500DPS;
    config.sample_rate_div = 9;
    config.gyro_dlpf_cfg = 3;
    config.accel_dlpf_cfg = 3;

    result = MPU9250_Init(&config);
    imu_ready = (result == MPU9250_OK) ? 1 : 0;
    if (!imu_ready)
    {
        printf("MPU9250 failed, code=%u\r\n", result);
        return;
    }

    MPU9250_ReadID(&id);
    imu_mag_ready = MPU9250_MagIsReady();
    if (imu_mag_ready)
    {
        MPU9250_ReadMagID(&mag_id);
    }

    printf("MPU9250 OK. id=0x%02X, AK8963=%s", id, imu_mag_ready ? "OK" : "NO");
    if (imu_mag_ready)
    {
        printf(", mag_id=0x%02X", mag_id);
    }
    printf("\r\n");

    MotionResetCounters();
    MotionCalibrate(40);
}

static void MotionProcessSample(uint32_t now_ms)
{
    u32 accel_mag;
    u32 accel_delta;
    s32 gyro_x;
    s32 gyro_y;

    accel_mag = MotionAccelMagnitudeMg(&imu_data);
    accel_delta = (accel_mag > motion_last_accel_mag_mg) ?
                  (accel_mag - motion_last_accel_mag_mg) :
                  (motion_last_accel_mag_mg - accel_mag);
    motion_last_accel_mag_mg = accel_mag;

    gyro_x = imu_data.gyro_dps_x100[0] - imu_gyro_bias_x100[0];
    gyro_y = imu_data.gyro_dps_x100[1] - imu_gyro_bias_x100[1];

    if (motion_step_armed && accel_mag > 1250 && (now_ms - motion_last_step_ms) > 280)
    {
        motion_step_count++;
        motion_last_step_ms = now_ms;
        motion_step_armed = 0;
    }
    else if (accel_mag < 1080)
    {
        motion_step_armed = 1;
    }

    if (accel_delta > 650 && (now_ms - motion_last_tap_ms) > 350)
    {
        motion_tap_count++;
        motion_last_tap_ms = now_ms;
        motion_alert_until_ms = now_ms + 120;
    }

    if ((Abs32(gyro_x) > 7000 || Abs32(gyro_y) > 7000) &&
        imu_data.accel_mg[2] > 250 &&
        imu_data.accel_mg[1] < 250 &&
        (now_ms - motion_last_lift_ms) > 1200)
    {
        motion_lift_count++;
        motion_last_lift_ms = now_ms;
        motion_alert_until_ms = now_ms + 180;
        current_page = PAGE_DASHBOARD;
    }
}

static void MotionSample(uint32_t now_ms)
{
    u8 result;

    if (!imu_ready)
    {
        return;
    }

    result = MPU9250_ReadData(&imu_data);
    if (result != MPU9250_OK)
    {
        imu_ready = 0;
        imu_mag_ready = 0;
        printf("MPU9250 I2C lost, code=%u\r\n", result);
        return;
    }

    imu_mag_ready = MPU9250_MagIsReady();
    MotionProcessSample(now_ms);
}

static void RetryFailedSensors(void)
{
    if (!bme_ready)
    {
        printf("Retrying BME280...\r\n");
        bme_ready = Bme280StationInit();
        printf("BME280 %s\r\n", bme_ready ? "OK" : "FAIL");
    }

    if (!vl53_ready)
    {
        printf("Retrying VL53L0X...\r\n");
        Vl53StationInit();
    }

    if (!max30102_ready)
    {
        printf("Retrying MAX30102...\r\n");
        Max30102StationInit();
    }

    if (!imu_ready)
    {
        printf("Retrying MPU9250...\r\n");
        MotionStationInit();
    }
}

static void Vl53Sample(void)
{
    if (!vl53_ready)
    {
        distance_mm = 65535;
        return;
    }

    distance_mm = VL53L0X_ReadFilteredMillimeters(2);
    if (VL53L0X_TimeoutOccurred())
    {
        printf("VL53L0X timeout\r\n");
        distance_mm = 65535;
    }
}

static void Max30102Sample(uint32_t now_ms)
{
    if (!max30102_ready)
    {
        return;
    }

    MAX30102_Task(now_ms, 0);
    if (!MAX30102_GetData()->ready)
    {
        max30102_ready = 0;
        printf("MAX30102 I2C lost\r\n");
    }
}

static void HandleKey(u8 key)
{
    if (key == KEY_NONE)
    {
        return;
    }

    if (key == KEY0_PRESS)
    {
        current_page = (StationPage)((current_page + 1) % PAGE_COUNT);
        printf("Page -> %s\r\n", page_names[current_page]);
    }
    else if (key == KEY1_PRESS)
    {
        if (current_page == PAGE_MOTION)
        {
            MotionResetCounters();
            printf("MOTION counters reset\r\n");
            return;
        }

        if (!vl53_ready)
        {
            printf("VL53L0X profile skipped: sensor not ready\r\n");
            return;
        }

        profile_index++;
        if (profile_index >= (sizeof(vl_profiles) / sizeof(vl_profiles[0])))
        {
            profile_index = 0;
        }

        VL53L0X_StopContinuous();
        if (VL53L0X_ApplyProfile(vl_profiles[profile_index]))
        {
            printf("VL53L0X profile -> %s, timing=%lu us\r\n",
                   vl_profile_names[profile_index], VL53L0X_GetMeasurementTimingBudget());
        }
        else
        {
            printf("VL53L0X profile switch failed\r\n");
        }
        VL53L0X_StartContinuous(0);
    }
    else if (key == KEY2_PRESS)
    {
        if (!alarm_enabled)
        {
            alarm_enabled = 1;
            threshold_index = 0;
        }
        else
        {
            threshold_index++;
            if (threshold_index >= (sizeof(alarm_thresholds) / sizeof(alarm_thresholds[0])))
            {
                threshold_index = 0;
                alarm_enabled = 0;
            }
        }
        printf("Distance alarm -> %s, threshold=%u mm\r\n",
               alarm_enabled ? "on" : "off", alarm_thresholds[threshold_index]);
    }
    else if (key == WKUP_PRESS)
    {
        if (current_page == PAGE_MOTION)
        {
            if (MotionCalibrate(60))
            {
                printf("MOTION calibration refreshed\r\n");
            }
            else
            {
                printf("MOTION calibration failed\r\n");
            }
            return;
        }

        if (!vl53_ready)
        {
            alarm_enabled = !alarm_enabled;
            printf("Alarm -> %s\r\n", alarm_enabled ? "on" : "off");
            return;
        }

        printf("Calibrating VL53L0X offset at %u mm...\r\n", CAL_TARGET_MM);
        VL53L0X_StopContinuous();
        if (VL53L0X_CalibrateOffset(CAL_TARGET_MM, 20))
        {
            printf("Calibration OK, offset=%d mm\r\n", (int)VL53L0X_GetOffset());
        }
        else
        {
            printf("Calibration failed\r\n");
        }
        VL53L0X_StartContinuous(0);
    }
}

static void ApplyLinkage(uint32_t now_ms)
{
    u16 threshold = alarm_thresholds[threshold_index];

    if (vl53_ready && distance_mm != 65535 && alarm_enabled && distance_mm <= threshold)
    {
        LED1 = 0;
        BEEP = 1;
    }
    else if (imu_ready && now_ms < motion_alert_until_ms)
    {
        LED1 = 0;
        BEEP = 1;
    }
    else
    {
        LED1 = 1;
        BEEP = 0;
    }
}

static void PrintStationFrame(void)
{
    printf("\r\n[%s] VL53L0X=%s BME280=%s MAX30102=%s MPU9250=%s MAG=%s alarm=%s threshold=%u mm\r\n",
           page_names[current_page],
           vl53_ready ? "OK" : "FAIL",
           bme_ready ? "OK" : "FAIL",
           max30102_ready ? "OK" : "FAIL",
           imu_ready ? "OK" : "FAIL",
           imu_mag_ready ? "OK" : "NO",
           alarm_enabled ? "on" : "off",
           alarm_thresholds[threshold_index]);

    if (current_page == PAGE_DASHBOARD)
    {
        if (vl53_ready && distance_mm != 65535)
        {
            printf("DIST: %u mm, offset=%d mm, profile=%s\r\n",
                   distance_mm, (int)VL53L0X_GetOffset(), vl_profile_names[profile_index]);
        }
        else
        {
            printf("DIST: not ready\r\n");
        }
        PrintBmeData();
        PrintHealthData();
        if (imu_ready)
        {
            printf("MOTION: posture=%s, steps=%lu, taps=%u, lifts=%u, heading=%s\r\n",
                   MotionPostureName(),
                   (unsigned long)motion_step_count,
                   motion_tap_count,
                   motion_lift_count,
                   MotionHeadingName());
        }
        else
        {
            printf("MOTION: MPU9250 not ready\r\n");
        }
    }
    else if (current_page == PAGE_ENVIRONMENT)
    {
        PrintBmeData();
    }
    else if (current_page == PAGE_DISTANCE)
    {
        if (vl53_ready && distance_mm != 65535)
        {
            printf("DIST: %u mm, threshold=%u mm, offset=%d mm, profile=%s\r\n",
                   distance_mm,
                   alarm_thresholds[threshold_index],
                   (int)VL53L0X_GetOffset(),
                   vl_profile_names[profile_index]);
        }
        else
        {
            printf("DIST: VL53L0X not ready\r\n");
        }
    }
    else if (current_page == PAGE_HEALTH)
    {
        PrintHealthData();
        printf("HEALTH: demo estimate only, not for medical use\r\n");
    }
    else if (current_page == PAGE_MOTION)
    {
        if (!imu_ready)
        {
            printf("MOTION: MPU9250 not ready. Check PB8/PB9, 3.3V, GND, AD0=GND.\r\n");
        }
        else
        {
            printf("MOTION: A=%ld,%ld,%ld mg, G=%ld.%02ld,%ld.%02ld,%ld.%02ld dps\r\n",
                   imu_data.accel_mg[0],
                   imu_data.accel_mg[1],
                   imu_data.accel_mg[2],
                   (imu_data.gyro_dps_x100[0] - imu_gyro_bias_x100[0]) / 100,
                   Abs32((imu_data.gyro_dps_x100[0] - imu_gyro_bias_x100[0]) % 100),
                   (imu_data.gyro_dps_x100[1] - imu_gyro_bias_x100[1]) / 100,
                   Abs32((imu_data.gyro_dps_x100[1] - imu_gyro_bias_x100[1]) % 100),
                   (imu_data.gyro_dps_x100[2] - imu_gyro_bias_x100[2]) / 100,
                   Abs32((imu_data.gyro_dps_x100[2] - imu_gyro_bias_x100[2]) % 100));
            printf("MOTION: posture=%s, heading=%s, steps=%lu, taps=%u, lifts=%u, cal=%s\r\n",
                   MotionPostureName(),
                   MotionHeadingName(),
                   (unsigned long)motion_step_count,
                   motion_tap_count,
                   motion_lift_count,
                   imu_calibrated ? "OK" : "NO");
            printf("MOTION keys: KEY1 reset counters, WK_UP still calibration.\r\n");
        }
    }
}

static void OledRender(void)
{
    char line[32];

    if (!OLED_IsReady())
    {
        return;
    }

    OLED_PrintLine(0, "WATCHSENSE-F407");

    sprintf(line, "PG:%s", page_names[current_page]);
    OLED_PrintLine(1, line);

    if (current_page == PAGE_DASHBOARD)
    {
        if (vl53_ready && distance_mm != 65535)
        {
            sprintf(line, "DIST:%uMM", distance_mm);
        }
        else
        {
            sprintf(line, "DIST: ----MM");
        }
        OLED_PrintLine(2, line);

        FormatBmeLine(line);
        OLED_PrintLine(3, line);

        FormatPressureLine(line);
        OLED_PrintLine(4, line);

        sprintf(line, "ALM:%s %uMM", alarm_enabled ? "ON" : "OFF",
                alarm_thresholds[threshold_index]);
        OLED_PrintLine(5, line);

        FormatHealthLine(line);
        OLED_PrintLine(6, line);

        sprintf(line, "V:%s B:%s H:%s M:%s",
                vl53_ready ? "OK" : "NO",
                bme_ready ? "OK" : "NO",
                max30102_ready ? "OK" : "NO",
                imu_ready ? "OK" : "NO");
        OLED_PrintLine(7, line);
    }
    else if (current_page == PAGE_ENVIRONMENT)
    {
        FormatBmeLine(line);
        OLED_PrintLine(2, line);
        FormatPressureLine(line);
        OLED_PrintLine(3, line);
        OLED_PrintLine(4, bme_ready ? "BME280: OK" : "BME280: FAIL");
        OLED_PrintLine(5, "SPI1 PA5/6/7 PA4");
        OLED_PrintLine(6, "KEY0 NEXT PAGE");
        OLED_PrintLine(7, "");
    }
    else if (current_page == PAGE_DISTANCE)
    {
        if (vl53_ready && distance_mm != 65535)
        {
            sprintf(line, "DIST:%uMM", distance_mm);
        }
        else
        {
            sprintf(line, "DIST: ----MM");
        }
        OLED_PrintLine(2, line);
        sprintf(line, "TH:%uMM %s", alarm_thresholds[threshold_index],
                alarm_enabled ? "ON" : "OFF");
        OLED_PrintLine(3, line);
        sprintf(line, "OFF:%dMM", (int)VL53L0X_GetOffset());
        OLED_PrintLine(4, line);
        sprintf(line, "MODE:%s", vl_profile_names[profile_index]);
        OLED_PrintLine(5, line);
        OLED_PrintLine(6, "WK_UP CAL 100MM");
        OLED_PrintLine(7, vl53_ready ? "VL53L0X: OK" : "VL53L0X: FAIL");
    }
    else if (current_page == PAGE_HEALTH)
    {
        const MAX30102_Data *data;

        data = MAX30102_GetData();
        FormatHealthLine(line);
        OLED_PrintLine(2, line);

        if (!max30102_ready || !data->ready)
        {
            OLED_PrintLine(3, "MAX30102: FAIL");
            OLED_PrintLine(4, "I2C PB8/PB9");
            OLED_PrintLine(5, "ADDR 0x57");
            OLED_PrintLine(6, "CHECK 3.3V/GND");
            OLED_PrintLine(7, "");
        }
        else
        {
            sprintf(line, "IR:%lu", (unsigned long)data->ir);
            OLED_PrintLine(3, line);
            sprintf(line, "RED:%lu", (unsigned long)data->red);
            OLED_PrintLine(4, line);
            sprintf(line, "BEAT:%u", data->beat_count);
            OLED_PrintLine(5, line);
            OLED_PrintLine(6, data->finger ? "FINGER: YES" : "FINGER: NO");
            OLED_PrintLine(7, "DEMO ESTIMATE");
        }
    }
    else if (current_page == PAGE_MOTION)
    {
        FormatMotionLine(line);
        OLED_PrintLine(2, line);
        sprintf(line, "TAP:%u LIFT:%u", motion_tap_count, motion_lift_count);
        OLED_PrintLine(3, line);
        sprintf(line, "MAG:%s HEAD:%s", imu_mag_ready ? "OK" : "NO", MotionHeadingName());
        OLED_PrintLine(4, line);
        if (imu_ready)
        {
            sprintf(line, "A:%ld,%ld,%ld",
                    imu_data.accel_mg[0],
                    imu_data.accel_mg[1],
                    imu_data.accel_mg[2]);
            OLED_PrintLine(5, line);
            sprintf(line, "TEMP:%ld.%02ldC",
                    imu_data.temperature_x100 / 100,
                    Abs32(imu_data.temperature_x100 % 100));
            OLED_PrintLine(6, line);
        }
        else
        {
            OLED_PrintLine(5, "MPU9250: FAIL");
            OLED_PrintLine(6, "PB8/PB9 ADDR 0x68");
        }
        OLED_PrintLine(7, "K1 RST WK CAL");
    }
}

int main(void)
{
    uint32_t now_ms = 0;
    uint32_t last_env_ms = 0;
    uint32_t last_dist_ms = 0;
    uint32_t last_motion_ms = 0;
    uint32_t last_ui_ms = 0;
    uint32_t last_retry_ms = 0;

    Stm32_Clock_Init(336, 8, 2, 7);
    delay_init(168);
    LED_Init();
    BEEP_Init();
    KEY_Init();
    uart_init(84, 115200);
    myI2C_init();

    LED0 = 1;
    LED1 = 1;
    BEEP = 0;

    printf("\r\nWatchSense-F407 desktop station prototype\r\n");
    printf("KEY0 page, KEY1 VL53L0X profile, KEY2 threshold, WK_UP VL53L0X calibration\r\n");
    printf("VL53L0X: PB8/PB9 I2C, PB5 XSHUT\r\n");
    printf("OLED: PB8/PB9 I2C, address 0x3C\r\n");
    printf("BME280: SPI1 PA5=SCK PA6=MISO PA7=MOSI PA4=CS\r\n");
    printf("MAX30102: PB8/PB9 I2C, address 0x57, demo HR/SpO2 estimate\r\n");
    printf("GY-91/MPU9250: PB8/PB9 I2C, address 0x68, AK8963 mag address 0x0C\r\n");

    printf("OLED %s\r\n", OLED_Init() ? "OK" : "FAIL");
    if (OLED_IsReady())
    {
        OLED_PrintLine(0, "WATCHSENSE-F407");
        OLED_PrintLine(1, "BOOTING...");
        OLED_PrintLine(2, "OLED OK");
        OLED_PrintLine(3, "SERIAL 115200");
    }

    bme_ready = Bme280StationInit();
    printf("BME280 %s\r\n", bme_ready ? "OK" : "FAIL");

    Vl53StationInit();

    Max30102StationInit();

    MotionStationInit();

    printf("Prototype is running. KEY0 page, motion page KEY1 reset, WK_UP calibrates current page.\r\n");

    while (1)
    {
        HandleKey(KeyScan());
        Max30102Sample(now_ms);

        if ((now_ms - last_motion_ms) >= 50)
        {
            MotionSample(now_ms);
            last_motion_ms = now_ms;
        }

        if ((now_ms - last_env_ms) >= 1000)
        {
            Bme280Sample();
            last_env_ms = now_ms;
        }

        if ((now_ms - last_dist_ms) >= 200)
        {
            Vl53Sample();
            last_dist_ms = now_ms;
        }

        ApplyLinkage(now_ms);

        if ((now_ms - last_ui_ms) >= 1000)
        {
            OledRender();
            PrintStationFrame();
            LED0 = !LED0;
            last_ui_ms = now_ms;
        }

        if ((now_ms - last_retry_ms) >= 5000)
        {
            RetryFailedSensors();
            last_retry_ms = now_ms;
        }

        delay_ms(20);
        now_ms += 20;
    }
}
