#ifndef __OLED_H
#define __OLED_H

#include "sys.h"

#define OLED_I2C_ADDR          0x3C
#define OLED_WIDTH             128
#define OLED_PAGES             8
#define OLED_CHARS_PER_LINE    21

u8 OLED_Init(void);
void OLED_Clear(void);
void OLED_SetCursor(u8 page, u8 col);
void OLED_ShowChar(u8 page, u8 col, char ch);
void OLED_ShowString(u8 page, u8 col, const char *str);
void OLED_PrintLine(u8 page, const char *str);
u8 OLED_IsReady(void);

#endif
