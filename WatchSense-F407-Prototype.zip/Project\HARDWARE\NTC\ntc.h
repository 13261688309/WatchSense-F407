#ifndef __NTC_H
#define __NTC_H	 
#include "sys.h" 

#define NTC GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_7 )
void NTC_Init(void);
#endif

