#ifndef __MAX30102_H
#define __MAX30102_H

#include "sys.h"
#include <stdint.h>

#define MAX30102_I2C_ADDR       0x57
#define MAX30102_EXPECTED_ID    0x15

typedef struct
{
    u8 ready;
    u8 finger;
    u8 part_id;
    u8 spo2_valid;
    u8 spo2;
    u16 bpm;
    u16 sample_count;
    u16 beat_count;
    uint32_t red;
    uint32_t ir;
    uint32_t last_beat_ms;
    int32_t ir_dc;
    int32_t red_dc;
    int32_t ir_ac;
    int32_t ac_abs_avg;
} MAX30102_Data;

u8 MAX30102_Init(void);
void MAX30102_Shutdown(void);
u8 MAX30102_Available(void);
u8 MAX30102_ReadFIFO(uint32_t *red, uint32_t *ir);
u8 MAX30102_Task(uint32_t now_ms, MAX30102_Data *out);
const MAX30102_Data *MAX30102_GetData(void);
u8 MAX30102_GetPartID(void);

#endif
