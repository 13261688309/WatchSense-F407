#ifndef __MAX6675_H
#define __MAX6675_H	 
#include "sys.h" 
#define CS PAout(4)

void MAX6675_init(void);
u16 SPI1_ReadWriteByte(u16 TxData);
u16 MAX6675_ReadByte(void);
#endif

